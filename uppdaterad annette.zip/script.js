document.addEventListener('DOMContentLoaded', function () {
    const resultatKnapp = document.getElementById('knapp2');
    resultatKnapp.addEventListener('click', beraknaResultat);
});
function beraknaResultat() {
    console.log('ok');
    const allaSvar = new Array(10);
    for (let i = 1; i <= 10; i++) {
        //allaSvar[i - 1] = document.getElementsByName('fraga' + i);
        for (let j = 0; j < allaSvar[i-1].length; i++){
            if ()
        }
        console.log(allaSvar[i]);
    }
    //console.log(allaSvar);

    let gulPoang = 0;
    let gronPoang = 0;
    let rosaPoang = 0;

    for (let i = 0; i < allaSvar.length; i++) {
        for (let j = 1; j <= 4; j++) {

            //j istället för i så att den inte blir förvirrad - det finns 2 i
            const svarKar = allaSvar[i].value;
            console.log(svarKar);
            if (svarKar === 'gul') {
                gulPoang++;
            } else if (svarKar === 'gron') {
                gronPoang++;
            } else if (svarKar === 'rosa') {
                rosaPoang++;
            }
        }
    }
    //denna funktion funkar inte^^

    console.log(gulPoang); console.log(rosaPoang); console.log(gronPoang);

    //document.body.removeChild(document.getElementById('knapp2'));
    const resultatDiv = document.createElement('div');
    const resultatP = document.createElement('p');
    let resultatKar = '';

    if (gulPoang > rosaPoang && gulPoang > gronPoang) {
        resultatKar = 'Du är gul!';
    } else if (rosaPoang > gulPoang && rosaPoang > gronPoang) {
        resultatKar = 'Du är rosa!';
    } else if (gronPoang > gulPoang && gronPoang > rosaPoang) {
        resultatKar = 'Du är grön!';
    }

    const resultatText = document.createTextNode(resultatKar);
    resultatP.appendChild(resultatText);
    resultatDiv.appendChild(resultatP);
    document.body.appendChild(resultatDiv);
}